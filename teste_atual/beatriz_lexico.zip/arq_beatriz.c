int main (){
    char name == "alice";
    printf ("Hello World");
}